
var gl;
var canvas;
var shaderProgram;
var vertexPositionBuffer;







// Create a place to store vertex colors
var vertexColorBuffer;



var colors;
var vertices;



var squares = [];
var s = [];
var s2 = [];
var s3 = [];
var density = [];
var density2 = [];
var density3 = [];
var vx = [];
var vy = [];
var vx0 = [];
var vy0 = [];


var vx1 = [];
var vy1 = [];
var vx01 = [];
var vy01 = [];

var vx2 = [];
var vy2 = [];
var vx02 = [];
var vy02 = [];

var vx3 = [];
var vy3 = [];
var vx03 = [];
var vy03 = [];

var N = 200;
var iter = 4;
var diff = 0;
var diff2 = 0;
var diff3 = 0;


var visc = 0;
var visc2 = 0;
var visc3 = 0;
var dt = 0.1;





var mvMatrix = mat4.create();






function setMatrixUniforms() {
  gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}





function createGLContext(canvas) {
  var names = ["webgl", "experimental-webgl"];
  var context = null;
  for (var i=0; i < names.length; i++) {
    try {
      context = canvas.getContext(names[i]);
    } catch(e) {}
    if (context) {
      break;
    }
  }
  if (context) {
    context.viewportWidth = canvas.width;
    context.viewportHeight = canvas.height;
  } else {
    alert("Failed to create WebGL context!");
  }
  return context;
}

function loadShaderFromDOM(id) {
  var shaderScript = document.getElementById(id);
  
  // If we don't find an element with the specified id
  // we do an early exit 
  if (!shaderScript) {
    return null;
  }
  
  // Loop through the children for the found DOM element and
  // build up the shader source code as a string
  var shaderSource = "";
  var currentChild = shaderScript.firstChild;
  while (currentChild) {
    if (currentChild.nodeType == 3) { // 3 corresponds to TEXT_NODE
      shaderSource += currentChild.textContent;
    }
    currentChild = currentChild.nextSibling;
  }
 
  var shader;
  if (shaderScript.type == "x-shader/x-fragment") {
    shader = gl.createShader(gl.FRAGMENT_SHADER);
  } else if (shaderScript.type == "x-shader/x-vertex") {
    shader = gl.createShader(gl.VERTEX_SHADER);
  } else {
    return null;
  }
 
  gl.shaderSource(shader, shaderSource);
  gl.compileShader(shader);
 
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    alert(gl.getShaderInfoLog(shader));
    return null;
  } 
  return shader;
}

function setupShaders() {
  vertexShader = loadShaderFromDOM("shader-vs");
  fragmentShader = loadShaderFromDOM("shader-fs");
  
  shaderProgram = gl.createProgram();
  gl.attachShader(shaderProgram, vertexShader);
  gl.attachShader(shaderProgram, fragmentShader);
  gl.linkProgram(shaderProgram);

  if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    alert("Failed to setup shaders");
  }

  gl.useProgram(shaderProgram);
  shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
  gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

  shaderProgram.vertexColorAttribute = gl.getAttribLocation(shaderProgram, "aVertexColor");
  gl.enableVertexAttribArray(shaderProgram.vertexColorAttribute);
  shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
  
}

var dye1On = false;
var dye2On = false;
var dye3On = false;

var dye1Rate = 0.1;
var dye2Rate = 0.1;
var dye3Rate = 0.1;


function enabledye1(ifOn)
{

  dye1On = ifOn;
  $("#sliderBar1").prop("disabled", !dye1On);
}
function enabledye2(ifOn)
{

  dye2On = ifOn;
  $("#sliderBar2").prop("disabled", !dye2On);
}
function enabledye3(ifOn)
{

  dye3On = ifOn;
  $("#sliderBar3").prop("disabled", !dye3On);
}

function updateDye1(sliderAmount) {
    $("#sliderAmountD1").html(sliderAmount/10);
    dye1Rate = sliderAmount/10;
}
function updateDye2(sliderAmount) {
    $("#sliderAmountD2").html(sliderAmount/10);
    dye2Rate = sliderAmount/10;
}
function updateDye3(sliderAmount) {
    $("#sliderAmountD3").html(sliderAmount/10);
    dye3Rate = sliderAmount/10;
}


var diff = 0;
var diff2 = 0;
var diff3 = 0;

var diffOn = false;
var diff2On = false;
var diff3On = false;

function enablediff1(ifOn)
{

  diffOn = ifOn;
  $("#sliderBarDiff1").prop("disabled", !diffOn);
}
function enablediff2(ifOn)
{

  diff2On = ifOn;
  $("#sliderBarDiff2").prop("disabled", !diff2On);
}
function enablediff3(ifOn)
{

  diff3On = ifOn;
  $("#sliderBarDiff3").prop("disabled", !diff3On);
}

function updateDiff1(sliderAmount) {
    $("#sliderAmountDiff1").html(-1 * sliderAmount);
    diff = Math.pow(10,-1 * sliderAmount);
}
function updateDiff2(sliderAmount) {
    $("#sliderAmountDiff2").html(-1 * sliderAmount);
    diff2 = Math.pow(10,-1 * sliderAmount);
}
function updateDiff3(sliderAmount) {
    $("#sliderAmountDiff3").html(-1 * sliderAmount);
    diff3 = Math.pow(10,-1 * sliderAmount);
}



var viscOn = false;
var visc2On = false;
var visc3On = false;

function enablevisc1(ifOn)
{

  viscOn = ifOn;
  $("#sliderBarVisc1").prop("disabled", !viscOn);
}
function enablevisc2(ifOn)
{

  visc2On = ifOn;
  $("#sliderBarVisc2").prop("disabled", !visc2On);
}
function enablevisc3(ifOn)
{

  visc3On = ifOn;
  $("#sliderBarVisc3").prop("disabled", !visc3On);
}

function updateVisc1(sliderAmount) {
    $("#sliderAmountVisc1").html(-1 * sliderAmount);
    visc = Math.pow(10,-1 * sliderAmount);
}
function updateVisc2(sliderAmount) {
    $("#sliderAmountVisc2").html(-1 * sliderAmount);
    visc2 = Math.pow(10,-1 * sliderAmount);
}
function updateVisc3(sliderAmount) {
    $("#sliderAmountVisc3").html(-1 * sliderAmount);
    visc3 = Math.pow(10,-1 * sliderAmount);
}



function Emit1()
{
  var num = Math.floor(Math.random()*2) + 1;
  num *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
  for (var j = Math.floor(N/2) - 2; j  <= Math.floor(N/2) + 2; j++)
  {
  density2[IX(3,j)] = 0.0;
  density3[IX(3,j)] = 0.0;
  density[IX(3,j)] += dye1Rate; 
  vx[IX(3,j)] += dt * (2 + dye1Rate*2); 
  vy[IX(3,j)] += dt * num;
  }
}
function Emit2()
{
  var num = Math.floor(Math.random()*2) + 1;
  num *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
  for (var j = Math.floor(N/2) - 2; j  <= Math.floor(N/2) + 2; j++)
  {
  density[IX(N-3,j)] = 0.0;
  density3[IX(N-3,j)] = 0.0;
  density2[IX(N-3,j)] += dye2Rate; 
  vx[IX(N-3,j)] -= dt * (2 + dye2Rate*2); 
  vy[IX(N-3,j)] += dt * num; 
  }
}
function Emit3()
{
  var num = Math.floor(Math.random()*2) + 1;
  num *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
  for (var j = Math.floor(N/2) - 2; j  <= Math.floor(N/2) + 2; j++)
  {
  density[IX(j,2)] = 0.0;
  density2[IX(j,2)] = 0.0;
  density3[IX(j,2)] += dye3Rate; 
  vy[IX(j,2)] += dt * (2 + dye3Rate*2); 
  vx[IX(j,2)] += dt * num; 
  }
}

function setColor(square, factor)
{
  
  s = square * 18;  
  colors[s] = factor;
  colors[s + 3] = factor;
  colors[s + 6] = factor;
  colors[s + 9] = factor;
  colors[s + 12] = factor;
  colors[s + 15] = factor;

}

function getColor(square)
{
  return colors[square * 18];
}


function setupBuffers() {
  vertexPositionBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexPositionBuffer);
 

  step = 0.01; //this determins the number of gridspaces
  var vertcount = 0;    //counting vertices
  

  vertices = []; //array of verts
  colors = [];  //color array
  for (i = -1; i < 1; i += step)
  {
    for (y = -1; y < 1; y += step)
    {

      vertices.push(i,  y, 0.0);
      vertices.push(i,  y + step, 0.0);
      vertices.push(i + step,  y, 0.0);

      vertices.push(i + step,  y + step, 0.0);
      vertices.push(i,  y + step, 0.0);
      vertices.push(i + step,  y, 0.0);
      
      colors.push(0.0,0.0,0.0);
      colors.push(0.0,0.0,0.0);
      colors.push(0.0,0.0,0.0);
      colors.push(0.0,0.0,0.0);
      colors.push(0.0,0.0,0.0);
      colors.push(0.0,0.0,0.0);
      vertcount += 6;


      s.push(0.0);
      s2.push(0.0);
      s3.push(0.0);
      density.push(0.0);
      density2.push(0.0);
      density3.push(0.0);
      vx.push(0.0);
      vy.push(0.0);
      vx0.push(0.0);
      vy0.push(0.0);
      
      vx1.push(0.0);
      vy1.push(0.0);
      vx01.push(0.0);
      vy01.push(0.0);
      
      vx2.push(0.0);
      vy2.push(0.0);
      vx02.push(0.0);
      vy02.push(0.0);
      
      vx3.push(0.0);
      vy3.push(0.0);
      vx03.push(0.0);
      vy03.push(0.0);
      } 
    }

  

  

  
  

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
  vertexPositionBuffer.itemSize = 3;
  vertexPositionBuffer.numberOfItems = vertcount;
    
  vertexColorBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexColorBuffer);




  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);
  vertexColorBuffer.itemSize = 3
  vertexColorBuffer.numItems = 3;  
}

function draw() { 


  gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);  
  mat4.identity(mvMatrix);

  mat4.translate(mvMatrix,mvMatrix,[0,0,0]);   //might not need this



  for (i = 0; i < density.length; i++)
  {
    
    o = i * 18;  
    colors[o+2] = density[i];
    colors[o+3+2] = density[i];
    colors[o+6+2] = density[i];
    colors[o+9+2] = density[i];
    colors[o+12+2] = density[i];
    colors[o+15+2] = density[i];

    p = i * 18;
    colors[p] = density2[i];
    colors[p+3] = density2[i];
    colors[p+6] = density2[i];
    colors[p+9] = density2[i];
    colors[p+12] = density2[i];
    colors[p+15] = density2[i];

    q = i * 18;
    colors[q + 1] = density3[i];
    colors[q+3 + 1] = density3[i];
    colors[q+6 + 1] = density3[i];
    colors[q+9 + 1] = density3[i];
    colors[q+12 + 1] = density3[i];
    colors[q+15 + 1] = density3[i];
    
    
  }



  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

  gl.bindBuffer(gl.ARRAY_BUFFER, vertexPositionBuffer);
  gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, 
                         vertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexColorBuffer);
  gl.vertexAttribPointer(shaderProgram.vertexColorAttribute, 
                            vertexColorBuffer.itemSize, gl.FLOAT, false, 0, 0);
  
  setMatrixUniforms();
  gl.drawArrays(gl.TRIANGLES, 0, vertexPositionBuffer.numberOfItems);
}




function startup() {


  canvas = document.getElementById("myGLCanvas");

  gl = createGLContext(canvas);
  setupShaders(); 
  setupBuffers();
  gl.clearColor(0.0, 0.0, 0.0, 1.0);
  gl.enable(gl.DEPTH_TEST);
  tick();
}


function IX(i,j)
{
  return i + (N) * j;
}


function addDensity(x,y,a)
{
  density[IX(x,y)] += a;
}

function addVelocity(x,y,ax,ay)
{
  vx[IX(x,y)] = ax;
  vy[IX(x,y)] = ay;
}

function set_bnd(b, x)
{
  for (var l = 0; l < x.length;l++)
  {
    for(var i = 1; i < N - 1; i++) {
      x[l][IX(i, 0)] = b[l] == 2 ? -x[l][IX(i, 1)] : x[l][IX(i, 1)];
      x[l][IX(i, N-1)] = b[l] == 2 ? -x[l][IX(i, N-2)] : x[l][IX(i, N-2)];

      x[l][IX(0  , i)] = b[l] == 1 ? -x[l][IX(1  , i)] : x[l][IX(1  , i)];
      x[l][IX(N-1, i)] = b[l] == 1 ? -x[l][IX(N-2, i)] : x[l][IX(N-2, i)];
    }
     
    x[l][IX(0 ,0 )] = 0.5*(x[l][IX(1,0 )]+x[l][IX(0 ,1)]);
    x[l][IX(0 ,N-1)] = 0.5*(x[l][IX(1,N-1)]+x[l][IX(0 ,N-2 )]);
    x[l][IX(N-1,0 )] = 0.5*(x[l][IX(N-2,0 )]+x[l][IX(N-1,1)]);
    x[l][IX(N-1,N-1)] = 0.5*(x[l][IX(N-2,N-1)]+x[l][IX(N-1,N-2 )]);
  }
}

function project(velocX, velocY, p, div)
{
    
    for (var j = 1; j < N - 1; j++) {
      for (var i = 1; i < N - 1; i++) {
        div[IX(i, j)] = -0.5*(velocX[IX(i+1, j)]
                             -velocX[IX(i-1, j)]
                             +velocY[IX(i  , j+1)]
                             -velocY[IX(i  , j-1)])/N;
        p[IX(i, j)] = 0;
      }
    }
    
    set_bnd([0], [div]); 
    set_bnd([0], [p]);

    for (var k = 0; k < iter; k++) {
        
      for (var j = 1; j < N - 1; j++) {
        for (var i = 1; i < N - 1; i++) {
          p[IX(i, j)] =
            (div[IX(i, j)]
            + (    p[IX(i+1, j)]
            +p[IX(i-1, j)]
            +p[IX(i  , j+1)]
            +p[IX(i  , j-1)]
            )) /4;
        }
      }    
        set_bnd([0], [p]);
    }    

    for (var j = 1; j < N - 1; j++) {
      for (var i = 1; i < N - 1; i++) {
        velocX[IX(i, j)] -= 0.5 * (  p[IX(i+1, j)]
                                    -p[IX(i-1, j)]) * N;
        velocY[IX(i, j)] -= 0.5 * (  p[IX(i, j+1)]
                                    -p[IX(i, j-1)]) * N;
      }
    }

    set_bnd([1], [velocX]);
    set_bnd([2], [velocY]);

}




function diffuse (b, x, x0,diff,diff2,diff3,dt,)
{
    var i,j,k;
    for (k = 0; k < 4; k++) {
      for (i=1; i<=N; i++) {
        for (j=1; j<=N; j++) {
          for (var l = 0; l < b.length;l++) {
          //Gambill method viscosity implimentation
          var visct;
          var m1 = 0.0; var m2 = 0.0; var m3 = 0.0; var d1 = 0.0; var d2 = 0.0;
          var V = density[IX(i,j)] + density2[IX(i,j)] + density3[IX(i,j)]; 
          var thresh = 0.0;
          if (density[IX(i,j)] > thresh) {
            m1 = density[IX(i,j)] * V * Math.pow(diff,1/3); //mv1
          }
          if (density2[IX(i,j)] > thresh) {
            m2 = density2[IX(i,j)] * V * Math.pow(diff2,1/3); //mv2
          }
          if (density3[IX(i,j)] > thresh) {
            m3 = density3[IX(i,j)] * V *  Math.pow(diff3,1/3); //mv3
          }
          //////

          visct = Math.pow(m1+m2+m3,3);
          
          var kt = dt * visct * (N - 2) * (N - 2);
           x[l][IX(i, j)] = (x0[l][IX(i, j)]
            + kt*(x[l][IX(i+1, j)] + x[l][IX(i-1, j)] 
                + x[l][IX(i, j+1)] + x[l][IX(i, j-1)]))/(1 +  4*kt);
        

          }
        }
      }
      set_bnd(b, x);        
    }


   
}


function diffuseDye(b, x, x0,diff,dt,)
{
    var i,j,k;          


    for (k = 0; k < 4; k++)
    {
      for (i=1; i<=N; i++)
      {
        for (j=1; j<=N; j++)
        {
          for (var l = 0; l < 3; l++)
          {
            var a = dt * diff[l]
           * (N - 2) * (N - 2);


            x[l][IX(i, j)] =
            (x0[l][IX(i, j)]
            + a*(    x[l][IX(i+1, j)]
            +x[l][IX(i-1, j)]
            +x[l][IX(i  , j+1)]
            +x[l][IX(i  , j-1)]))/(1 +  4*a);
          }
        }
      }

      //set bounds
      set_bnd([b], x);

    }


   
}



function advect(b, d, d0, velocX, velocY, dt)
{
    var i0, i1, j0, j1;
    
    var dtx = dt * (N - 2);
    var dty = dt * (N - 2);

    
    var s0, s1, t0, t1;
    var tmp1, tmp2, x, y;
    
    var Nfloat = N;
    var ifloat, jfloat;
    var i, j;
    

        for(j = 1, jfloat = 1; j < N - 1; j++, jfloat++) { 
            for(i = 1, ifloat = 1; i < N - 1; i++, ifloat++) {
              for (var l = 0; l < d.length;l++)
              {

                //find the previous points using the distance
                tmp1 = dtx * velocX[IX(i, j)];
                tmp2 = dty * velocY[IX(i, j)];
                
                x    = ifloat - tmp1; 
                y    = jfloat - tmp2;
                
                
                //get the neighboring points and scales
                if(x < 0.5) x = 0.5; 
                if(x > Nfloat + 0.5) x = Nfloat + 0.5; 
                i0 = Math.floor(x); 
                i1 = i0 + 1.0;
                if(y < 0.5) y = 0.5; 
                if(y > Nfloat + 0.5) y = Nfloat + 0.5; 
                j0 = Math.floor(y);
                j1 = j0 + 1.0; 
                
                s1 = x - i0; 
                s0 = 1.0 - s1; 
                t1 = y - j0; 
                t0 = 1.0 - t1;
                

                var i0i = Math.floor(i0);
                var i1i = Math.floor(i1);
                var j0i = Math.floor(j0);
                var j1i = Math.floor(j1);
                

                //set the current position to the combined value of the previous point calculation
                d[l][IX(i, j)] = s0 * ( t0 * d0[l][IX(i0i, j0i )] + t1 * d0[l][IX(i0i, j1i )])
                   +s1 * ( t0 * d0[l][IX(i1i, j0i )] +  t1 * d0[l][IX(i1i, j1i )]);
              }     
            }
        }
    

      set_bnd(b, d);      


}






function sim() {


  if (dye1On)
  {
    Emit1();      
  }
  if(dye2On)
  {
    Emit2();
  }
  if(dye3On)
  {
    Emit3();
  }


  
  var v1 = viscOn ? visc : 0.0;
  var v2 = visc2On ? visc2 : 0.0;
  var v3 = visc3On ? visc3 : 0.0;


  diffuse([1,2], [vx0,vy0], [vx,vy], v1,v2,v3, dt);
  project(vx0, vy0, vx, vy);
  advect([1,2], [vx,vy], [vx0,vy0], vx0, vy0, dt);
  project(vx, vy, vx0, vy0);


  var d1 = diffOn ? diff : 0.0;
  var d2 = diff2On ? diff2 : 0.0;
  var d3 = diff3On ? diff3 : 0.0;

  diffuseDye([0,0,0], [s,s2,s3], [density,density2,density3], [d1, d2, d3], dt);
  advect([0,0,0], [density,density2,density3], [s,s2,s3], vx, vy, dt);

}


function tick() {
    
    requestAnimFrame(tick);
    sim();
    draw();

}
